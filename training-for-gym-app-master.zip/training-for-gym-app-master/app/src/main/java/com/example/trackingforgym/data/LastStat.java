package com.example.trackingforgym.data;

public class LastStat {
    int id_serie;
    public String nombre;
    public int usos;
    public LastStat(int id_serie, String nombre, int usos){
        this.id_serie=id_serie;
        this.nombre=nombre;
        this.usos=usos;
    }
}
